import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JLayeredPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.RandomAccessFile;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JScrollPane;
import java.awt.Font;

public class Alunni extends JFrame {
	public DefaultListModel dlm =new DefaultListModel();
	public DefaultListModel dlm1 =new DefaultListModel();
	public DefaultListModel dlm2 =new DefaultListModel();
	public DefaultListModel dlm3 =new DefaultListModel();
	static String cod_al,cognome,nome,classe;	
	static int i=0,c=0;
	public static String cog[] = new String [1000];
	public static String nom[] = new String [1000];
	public static long a[] = new long [1000];
	public static String cod[] = new String [1000];
	public static String cl[] = new String [1000];
	public static long puntatore;
	private JPanel contentPane;
	private JTextField a1;
	private JTextField b1;
	private JTextField c1;
	private JTextField d1;
	private JTextField a2;
	private JTextField a3;
	private JTextField b3;
	private JTextField a4;

	public static void main(String[] args) {
		carica_vettore();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Alunni frame = new Alunni();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static void carica_vettore(){
		try {
			RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
			while(true) {
				try {
					cod_al=raf.readUTF();
					cognome=raf.readUTF();
					nome=raf.readUTF();
					classe=raf.readUTF();
					puntatore=raf.getFilePointer();
					c++;
					a[c]=puntatore;
					cod[c]=cod_al;
					cog[c]=cognome;
					nom[c]=nome;
					cl[c]=classe;
					raf.setLength(a[c]);	
				}
				catch(EOFException x) {
					break;
				}
			}
			
			raf.close();
			
		}
		catch(Exception e1) {
			
		}
		
	}
	
	public Alunni() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 656, 409);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 620, 348);
		contentPane.add(tabbedPane);
		
		JLayeredPane layeredPane = new JLayeredPane();
		tabbedPane.addTab("Crea", null, layeredPane, null);
		
		JButton btnNewButton = new JButton("Crea file Alunni");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
					raf.close();
				}
				
				catch(Exception e1) {
				}
			}
		});
		btnNewButton.setBounds(199, 133, 161, 23);
		layeredPane.add(btnNewButton);
		
		JLayeredPane layeredPane_1 = new JLayeredPane();
		tabbedPane.addTab("Registrazione", null, layeredPane_1, null);
		
		JLabel lblNewLabel = new JLabel("Insertisci il codice del alunno:");
		lblNewLabel.setBounds(37, 42, 172, 14);
		layeredPane_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Inserisci il cognome:");
		lblNewLabel_1.setBounds(37, 92, 155, 14);
		layeredPane_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Inserisci il nome:");
		lblNewLabel_2.setBounds(37, 144, 155, 14);
		layeredPane_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Inserisci la classe:");
		lblNewLabel_3.setBounds(37, 204, 112, 14);
		layeredPane_1.add(lblNewLabel_3);
		
		a1 = new JTextField();
		a1.setBounds(219, 39, 86, 20);
		layeredPane_1.add(a1);
		a1.setColumns(10);
		
		b1 = new JTextField();
		b1.setBounds(219, 89, 86, 20);
		layeredPane_1.add(b1);
		b1.setColumns(10);
		
		c1 = new JTextField();
		c1.setBounds(219, 141, 86, 20);
		layeredPane_1.add(c1);
		c1.setColumns(10);
		
		d1 = new JTextField();
		d1.setBounds(219, 201, 86, 20);
		layeredPane_1.add(d1);
		d1.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Registra");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
					
					raf.seek(raf.length()); 
					
					raf.writeUTF(a1.getText());
					raf.writeUTF(b1.getText());
					raf.writeUTF(c1.getText());
					raf.writeUTF(d1.getText());
					
					c++;
					a[c]=raf.getFilePointer();
					cod[c]=a1.getText();
					cog[c]=b1.getText();
					nom[c]=c1.getText();		
					cl[c]=d1.getText();
										
					a1.setText("");
					b1.setText("");
					c1.setText("");
					d1.setText("");
					
				
					
					raf.close();
					}
				catch(Exception e1) {
					
				}
			}
		});
		btnNewButton_1.setBounds(219, 251, 89, 23);
		layeredPane_1.add(btnNewButton_1);
		
		JLayeredPane layeredPane_2 = new JLayeredPane();
		tabbedPane.addTab("Visualizzazione", null, layeredPane_2, null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(177, 29, 407, 268);
		layeredPane_2.add(scrollPane);
		
		JList list = new JList();
		scrollPane.setViewportView(list);
		
		JButton btnNewButton_2 = new JButton("Visualizza");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlm.clear();
				String cod, cog, nome, cl;
				try {
					RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
					
					while(true) {
						try {
							cod=raf.readUTF();
							cog=raf.readUTF();
							nome=raf.readUTF();
							cl=raf.readUTF();
							a[c]=raf.getFilePointer();
							
							dlm.addElement("Codice alunno:"+cod);
							dlm.addElement("Cognome:"+cog);
							dlm.addElement("Nome:"+nome);
							dlm.addElement("Classe:"+cl);
							dlm.addElement("Puntatore:"+a[c]);
							dlm.addElement("________________________");
							c++;
						}
						catch(EOFException x) {
							break;
						}
					}
					list.setModel(dlm);
					raf.close();
					
				}
				catch(Exception e1) {
					
				}
			}
		});
		btnNewButton_2.setBounds(37, 40, 105, 23);
		layeredPane_2.add(btnNewButton_2);
		
		JLayeredPane layeredPane_3 = new JLayeredPane();
		tabbedPane.addTab("Ricerca", null, layeredPane_3, null);
		
		JLabel lblNewLabel_4 = new JLabel("Inserisci il codice di alunno:");
		lblNewLabel_4.setBounds(34, 50, 182, 14);
		layeredPane_3.add(lblNewLabel_4);
		
		a2 = new JTextField();
		a2.setBounds(219, 47, 99, 20);
		layeredPane_3.add(a2);
		a2.setColumns(10);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(34, 94, 498, 194);
		layeredPane_3.add(scrollPane_1);
		
		JList list_1 = new JList();
		scrollPane_1.setViewportView(list_1);
		
		JButton btnNewButton_3 = new JButton("Cerca");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlm1.clear();
				String cod_i=a2.getText();
				String codd, cog, nom, cl;
				try {
					RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
					
					for(i=1; i<=c; i++) {
						if(cod[i].equals(cod_i)) {
							puntatore=a[i-1];break;
						}
					}
					raf.seek(puntatore);
					codd=raf.readUTF();
					cog=raf.readUTF();
					nom=raf.readUTF();
					cl=raf.readUTF();
					
					
					dlm1.addElement("Codice alunno:"+codd);
					dlm1.addElement("Cognome:"+cog);
					dlm1.addElement("Nome:"+nom);
					dlm1.addElement("Classe:"+cl);
					raf.close();		
					list_1.setModel(dlm1);
								
				a2.setText(" ");
				}catch(Exception e1) {
					
				}			
				
			}
		});
		btnNewButton_3.setBounds(431, 46, 89, 23);
		layeredPane_3.add(btnNewButton_3);
		
		JLayeredPane layeredPane_4 = new JLayeredPane();
		tabbedPane.addTab("Modiffica", null, layeredPane_4, null);
		
		JLabel lblNewLabel_5 = new JLabel("Modifica della classe di un alunno F.I codice");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(153, 32, 309, 14);
		layeredPane_4.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Inserisci il codice:");
		lblNewLabel_6.setBounds(29, 109, 126, 14);
		layeredPane_4.add(lblNewLabel_6);
		
		a3 = new JTextField();
		a3.setBounds(219, 106, 102, 20);
		layeredPane_4.add(a3);
		a3.setColumns(10);
		
		b3 = new JTextField();
		b3.setBounds(219, 146, 102, 20);
		layeredPane_4.add(b3);
		b3.setColumns(10);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(358, 58, 224, 250);
		layeredPane_4.add(scrollPane_2);
		
		JList list_2 = new JList();
		scrollPane_2.setViewportView(list_2);
		JButton btnNewButton_4 = new JButton("Modifica");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlm2.clear();
				String cod_i=a3.getText();
				String classe_i=b3.getText();
				try {				
					for(i=1;i<=c;i++) {
						if(cod[i].equals(cod_i)) {					
						dlm2.addElement("I DATI PRECCEDENTI:");
						dlm2.addElement("Codice alunno:"+cod[i]);
						dlm2.addElement("Cognome:"+cog[i]);
						dlm2.addElement("Nome:"+nom[i]);
						dlm2.addElement("Classe:"+cl[i]);
						dlm2.addElement("Puntatore:"+a[i]);
						dlm2.addElement("________________________");
						cl[i]=classe_i;
						}
					}
					list_2.setModel(dlm2);
					modifica();				
					visualizzo(cod_i);	
					carica_vettore();
					
				}catch(Exception e1) {
					
				}
				
			}
			
		void modifica() {	
			try {
			RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
			
			for(i=1;i<=c;i++) {
				raf.writeUTF(cod[i]);
				raf.writeUTF(cog[i]);
				raf.writeUTF(nom[i]);
				raf.writeUTF(cl[i]);
	
			}
			raf.close();
			}catch(Exception e1) {
				
			}
		}
		void visualizzo(String codi) {	
			String codd, cog, nome, cl;
			try {
				RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");	
				
				for(i=1;i<=c;i++) {
					if(cod[i].equals(codi)) {
						puntatore=a[i-1];break;
						
					}
				}	
					
				raf.seek(puntatore);
				codd=raf.readUTF();
				cog=raf.readUTF();
				nome=raf.readUTF();
				cl=raf.readUTF();
				
				dlm2.addElement("I DATI MODIFICATI:");
				dlm2.addElement("Codice alunno:"+codd);
				dlm2.addElement("Cognome:"+cog);
				dlm2.addElement("Nome:"+nome);
				dlm2.addElement("Classe:"+cl);
				dlm2.addElement("________________________");
				list_2.setModel(dlm2);	
				raf.close();						
					}catch(Exception e1) {
						
					}
				}
				
			
		});
		btnNewButton_4.setBounds(232, 190, 89, 23);
		layeredPane_4.add(btnNewButton_4);
			
		JLabel lblNewLabel_8 = new JLabel("Inserisci la classe da modificare:");
		lblNewLabel_8.setBounds(29, 149, 169, 14);
		layeredPane_4.add(lblNewLabel_8);
		
	
		
		JLayeredPane layeredPane_5 = new JLayeredPane();
		tabbedPane.addTab("Elimina", null, layeredPane_5, null);
		
		JLabel lblNewLabel_7 = new JLabel("Eliminazione di un record:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_7.setBounds(203, 31, 214, 14);
		layeredPane_5.add(lblNewLabel_7);
		
		JLabel lblNewLabel_9 = new JLabel("Inserisci un record da eliminare:");
		lblNewLabel_9.setBounds(43, 83, 196, 14);
		layeredPane_5.add(lblNewLabel_9);
		
		a4 = new JTextField();
		a4.setBounds(249, 80, 86, 20);
		layeredPane_5.add(a4);
		a4.setColumns(10);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(43, 125, 398, 184);
		layeredPane_5.add(scrollPane_3);
		
		JList list_3 = new JList();
		scrollPane_3.setViewportView(list_3);
		
		JButton btnNewButton_5 = new JButton("Elimina");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dlm3.clear();
				try {
					String cod_i=a4.getText();
					
					RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
					for(i=1;i<=c;i++) {
						if(cod[i].equals(cod_i)) {
							puntatore=a[i-1];	break;
						}	
							raf.seek(puntatore);
							cod_al=raf.readUTF();
							cognome=raf.readUTF();
							nome=raf.readUTF();
							classe=raf.readUTF();
					
					dlm3.addElement("I DATI DA ELIMINARE:");
					dlm3.addElement("Codice alunno:"+cod_al);
					dlm3.addElement("Cognome:"+cognome);
					dlm3.addElement("Nome:"+nome);
					dlm3.addElement("Classe:"+classe);
					dlm3.addElement("Puntatore:"+a[i]);
					dlm3.addElement("-------------------------");
							
				
					list_3.setModel(dlm3);
					}
				raf.close();
				ricarica(puntatore,i);
				carica_vettore();
				vis();
				
				a4.setText(" ");
				}catch(Exception e1) {
					
				}
			}
			void ricarica(long punt,int i){
				try {
					RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");			
					raf.seek(punt);
					if(i==c) {
						raf.close();
						elimina();
						ricreazione();		
					}else {
						i++;
						while(i<=(c-1)) {
								raf.writeUTF(cod[i]);
								raf.writeUTF(nom[i]);
								raf.writeUTF(cog[i]);
								raf.writeUTF(cl[i]);
								i++;
						}
					}
				raf.setLength(a[i]);
				raf.close();
			
				}catch(Exception e1) {
					
				}
			}
				void elimina() {
					try {
						File canc = new File("ALUNNI.DAT");
						canc.delete();
					}catch(Exception e) {System.out.println("errore"+ e);}
				}
				void ricreazione() {
					try {
						System.out.println("");
						RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");
						int i=1;
						while(i<=(c-1)) {
							raf.writeUTF(cod[i]);
							raf.writeUTF(nom[i]);
							raf.writeUTF(cog[i]);
							raf.writeUTF(cl[i]);
							i++;	
						}
						raf.setLength(a[i]);	
						raf.close();
					}catch(Exception e) {}
				}
			void vis() {	
				String cod, cog, nome, cl;
					try {
						dlm3.addElement("I DATI RINNOVATI:");
						RandomAccessFile raf=new RandomAccessFile("ALUNNI.DAT","rw");	
						raf.seek(0);
						while(true) {
							try {					
								cod=raf.readUTF();
								cog=raf.readUTF();
								nome=raf.readUTF();
								cl=raf.readUTF();
								a[c]=raf.getFilePointer();
								
							
								dlm3.addElement("Codice alunno:"+cod);
								dlm3.addElement("Cognome:"+cog);
								dlm3.addElement("Nome:"+nome);
								dlm3.addElement("Classe:"+cl);
								dlm3.addElement("Puntatore:"+a[c]);
								dlm3.addElement("________________________");
								c++;
							}
							catch(EOFException x) {
								break;
							}
						}
						list_3.setModel(dlm3);
						raf.close();					
					
			}catch(Exception e1) {
				
			}
			}
		});
		btnNewButton_5.setBounds(357, 79, 89, 23);
		layeredPane_5.add(btnNewButton_5);	
	}
}
